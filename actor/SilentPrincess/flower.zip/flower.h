#ifndef FLOWER_H
#define FLOWER_H

#include "ultra64.h"
#include "global.h"

struct EnVase;

typedef struct EnVase {
    Actor actor;
} Flower;

#endif
