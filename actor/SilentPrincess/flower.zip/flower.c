/**
 * @file flower.c
 * @author zel.
 * @brief Flower for ending scene
 * @date 2021-12-31
 *
 * @copyright Copyright (c) 2021
 *
 */

#include "flower.h"
#include "objects/object_vase/object_vase.h"

extern bool Statics_UncullObject(GlobalContext* globalCtx, Vec3f* center, float xsize, float yBelow, float yAbove,
                                 float zBehind, float zFar);
extern Gfx flower_shape_mat_dl[];
extern Gfx flower_shape_tri_dl[];

#define FLAGS 0x00000030

#define FLOWER_MAX 20

void Flower_Init(Actor* thisx, GlobalContext* globalCtx);
void Flower_Destroy(Actor* thisx, GlobalContext* globalCtx);
void Flower_Update(Actor* thisx, GlobalContext* globalCtx);
void Flower_Draw(Actor* thisx, GlobalContext* globalCtx);

const ActorInit En_Vase_InitVars = {
    ACTOR_EN_VASE,
    ACTORCAT_PROP,
    FLAGS,
    OBJECT_VASE,
    sizeof(Flower),
    (ActorFunc)Flower_Init,
    (ActorFunc)Flower_Destroy,
    (ActorFunc)Flower_Update,
    (ActorFunc)Flower_Draw,
};

static Vec3f posList[FLOWER_MAX];
static s16 posHead = 0;
static Actor* flowerParent = NULL;

typedef enum {
    REG_SUCCESS,
    REG_ERROR
} RegisterResult;

RegisterResult Flower_RegisterPosition(Actor* thisx) {
    // Check if enough entries remain
    if (posHead > FLOWER_MAX - 1) {
        return REG_ERROR;
    }

    // Register the flower's position in the list
    posList[posHead] = thisx->world.pos;
    posHead++;

    // Kill any actors besides the first one the game spawns
    if (flowerParent == NULL) {
        flowerParent = thisx;
    } else {
        Actor_Kill(thisx);
    }

    return REG_SUCCESS;
}

void Flower_Init(Actor* thisx, GlobalContext* globalCtx) {
    Flower* this = (Flower*)thisx;

    Flower_RegisterPosition(thisx);

    if (flowerParent == thisx) {
        Actor_SetScale(&this->actor, 0.01f);
    }
}

void Flower_Update(Actor* thisx, GlobalContext* globalCtx) {
    // no op
}

void Flower_Destroy(Actor* thisx, GlobalContext* globalCtx) {
    // no op
}

void Flower_Draw(Actor* thisx, GlobalContext* globalCtx) {
    s32 i;

    OPEN_DISPS(globalCtx->state.gfxCtx);

    // Reset RDP state for OPA drawing
    func_80093D18(globalCtx->state.gfxCtx);

    for (i = 0; i < posHead + 1; i++) {
        // Load material for the flower
        gSPDisplayList(POLY_OPA_DISP++, flower_shape_mat_dl);

        // Check if the flower is on screen or not
        if (Statics_UncullObject(globalCtx, &posList[i], 3, 0, 5, 0, 0)) {
            // Translate the position of the flower
            Matrix_Translate(posList[i].x, posList[i].y, posList[i].z, MTXMODE_NEW);
            gSPMatrix(POLY_OPA_DISP++, Matrix_NewMtx(globalCtx->state.gfxCtx), G_MTX_MODELVIEW | G_MTX_LOAD);

            // Draw the flower geometry
            gSPDisplayList(POLY_OPA_DISP++, flower_shape_tri_dl);
        }
    }

    CLOSE_DISPS(globalCtx->state.gfxCtx);
}
